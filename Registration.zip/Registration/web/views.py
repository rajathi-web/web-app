from django.shortcuts import render, redirect
from web.forms import userform
from web.models import user


def euser(request):
    if request.method == "POST":
        form = userform(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect()
            except:
                pass
    else:
        form = userform()
    return render(request, "", {'forms': form})

# Create your views here.
