from django.db import models


class user(models.Model):
    code = models.Charfield(max_length=20)
    name = models.Charfield(max_lenght=20)
    contact = models.Charfield(max_lenght=20)
    email = models.Charfield(max_length=25)

    class Meta:
        db_table = "user"
