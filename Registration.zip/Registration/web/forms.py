from django import forms
from web.models import user


class userform(forms.Modelforms):
    class Meta:
        model = user
        Fields = "__all__"
